#!/bin/bash

cd tmp/scoring/
./scoreboard_exe